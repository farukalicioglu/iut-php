<?php
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title></title>
<META http-equiv="refresh" content="2;URL=https://blogs.windows.com/windowsexperience/2017/01/10/continuing-commitment-privacy-windows-10/#66T5jBGzc8iWjhU5.97">
</head>
<script>
